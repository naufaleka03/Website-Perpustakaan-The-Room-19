"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { submitInventoryItem } from "@/app/lib/actions";
import { createClient } from "@/app/supabase/client";

export default function CreateItem() {
  const router = useRouter();
  const supabase = createClient();
  const [item_name, setItemName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [item_image, setItemImage] = useState(null);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [imagePreview, setImagePreview] = useState(null);

  // Fetch categories when component mounts
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch("/api/categories");
        const data = await response.json();
        if (data.success) {
          setCategories(data.data);
        } else {
          setError("Failed to fetch categories");
        }
      } catch (error) {
        setError("Error loading categories");
      }
    };

    fetchCategories();
  }, []);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setError("File size should not exceed 5MB");
        return;
      }

      // Validate file type
      if (!file.type.startsWith("image/")) {
        setError("Please upload an image file");
        return;
      }

      setItemImage(file);
      // Create preview URL
      const previewUrl = URL.createObjectURL(file);
      setImagePreview(previewUrl);
      setError(""); // Clear any previous errors
    }
  };

  const uploadItemImage = async (file) => {
    if (!file) return null;

    try {
      // Create unique filename
      const fileExt = file.name.split(".").pop();
      const fileName = `${Date.now()}-${Math.random()
        .toString(36)
        .substring(2, 15)}.${fileExt}`;
      const filePath = `inventory/${fileName}`;

      // Upload file to Supabase Storage
      const { data, error: uploadError } = await supabase.storage
        .from("inventory-images")
        .upload(filePath, file, {
          cacheControl: "3600",
          upsert: false,
          contentType: file.type,
        });

      if (uploadError) {
        console.error("Upload Error:", uploadError);
        throw new Error(uploadError.message || "Failed to upload image");
      }

      if (!data?.path) {
        throw new Error("No upload data received");
      }

      // Get public URL
      const { data: urlData, error: urlError } = await supabase.storage
        .from("inventory-images")
        .getPublicUrl(data.path);

      if (urlError) {
        console.error("URL Error:", urlError);
        throw new Error(urlError.message || "Failed to get image URL");
      }

      return urlData.publicUrl;
    } catch (error) {
      console.error("Error in uploadItemImage:", error);
      throw new Error(error.message || "Failed to process image upload");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError("");

    try {
      // Validate form
      if (!item_name.trim()) {
        throw new Error("Item name is required");
      }
      if (!price || isNaN(parseFloat(price))) {
        throw new Error("Valid price is required");
      }

      let imageUrl = null;
      if (item_image) {
        try {
          imageUrl = await uploadItemImage(item_image);
        } catch (uploadError) {
          setError(uploadError.message || "Failed to upload image");
          setIsSubmitting(false);
          return;
        }
      }

      const formData = {
        item_name: item_name.trim(),
        description: description.trim(),
        price: parseFloat(price.replace(/[^0-9.]/g, "")),
        item_image: imageUrl,
        category_id: selectedCategory || null,
        stock_quantity: 0, // Default value for new items
      };

      console.log("Submitting form data:", formData); // Debug log

      const result = await submitInventoryItem(formData);

      if (result.success) {
        router.push("/staff/dashboard/inventory/inventory-list");
        router.refresh();
      } else {
        throw new Error(result.error || "Failed to create item");
      }
    } catch (err) {
      console.error("Error submitting item:", err);
      setError(err.message || "An unexpected error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full min-h-screen mx-auto bg-gradient-to-br from-[#232310] to-[#5f5f2c] px-0 pb-8">
      {/* Hero Section */}
      <div className="relative mb-8 mt-0">
        <img
          className="w-full h-[200px] object-cover"
          src="https://via.placeholder.com/1402x272"
        />
        <div className="absolute inset-0 flex items-center bg-gradient-to-l from-[#4d4d4d]/80 to-black/90 w-full mx-auto px-4 lg:px-8">
          <div className="max-w-[1200px] mx-auto w-full">
            <h1 className="text-[#fcfcfc] text-5xl font-medium leading-[48px] font-manrope mb-2">
              ADD NEW <br />
              ITEM
            </h1>
          </div>
        </div>
      </div>

      {/* Form Section */}
      <div className="max-w-[1000px] mx-auto px-6 lg:px-8 mb-12">
        <div className="bg-white rounded-xl shadow-md p-8 mb-8">
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {/* Item Name */}
            <div className="space-y-1">
              <label className="text-[#666666] text-sm font-medium font-['Poppins']">
                Item Name
              </label>
              <input
                type="text"
                value={item_name}
                onChange={(e) => setItemName(e.target.value)}
                placeholder="Enter Item Name"
                className="h-[35px] w-full rounded-lg border border-[#666666]/30 px-4 text-sm font-normal font-['Poppins'] text-[#666666]"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                Enter the name of the item.
              </p>
            </div>

            {/* Description */}
            <div className="space-y-1">
              <label className="text-[#666666] text-sm font-medium font-['Poppins']">
                Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter Description"
                className="w-full rounded-lg border border-[#666666]/30 px-4 py-2 text-sm font-normal font-['Poppins'] text-[#666666] min-h-[100px]"
              />
              <p className="text-xs text-gray-500 mt-1">
                Provide a brief description of the item.
              </p>
            </div>

            {/* Category Dropdown */}
            <div className="space-y-1">
              <label className="text-[#666666] text-sm font-medium font-['Poppins']">
                Category
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="h-[35px] w-full rounded-lg border border-[#666666]/30 px-4 text-sm font-normal font-['Poppins'] text-[#666666]"
                required
              >
                <option value="">Select a category</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.category_name}
                  </option>
                ))}
              </select>
              <p className="text-xs text-gray-500 mt-1">
                Select the category for this item.
              </p>
            </div>

            {/* Price */}
            <div className="space-y-1">
              <label className="text-[#666666] text-sm font-medium font-['Poppins']">
                Price
              </label>
              <input
                type="text"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="Enter Price"
                className="h-[35px] w-full rounded-lg border border-[#666666]/30 px-4 text-sm font-normal font-['Poppins'] text-[#666666]"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                Enter the price of the item (in IDR).
              </p>
            </div>

            {/* Upload Item Image */}
            <div className="space-y-1">
              <label className="text-[#666666] text-sm font-medium font-['Poppins']">
                Upload Item Image
              </label>
              <div className="relative">
                <input
                  type="file"
                  onChange={handleImageUpload}
                  className="absolute opacity-0 w-full h-full cursor-pointer"
                  accept="image/*"
                />
                <div className="h-[35px] w-full rounded-lg border border-[#666666]/30 px-4 flex items-center">
                  <span
                    className={`text-sm font-normal font-['Poppins'] ${
                      item_image ? "text-[#666666]" : "text-[#A9A9A9]"
                    }`}
                  >
                    {item_image ? item_image.name : "Choose file or drop here"}
                  </span>
                </div>
              </div>
              {imagePreview && (
                <div className="mt-2">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="w-32 h-32 object-cover rounded-lg"
                  />
                </div>
              )}
              <p className="text-xs text-gray-500 mt-1">
                Upload an image of the item. Max size: 5MB.
              </p>
            </div>

            {/* Error Message */}
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-2 rounded-lg text-sm">
                {error}
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className={`h-[40px] w-full rounded-3xl text-white text-base font-semibold mt-[20px] font-manrope transition-colors duration-200 ${
                isSubmitting
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-[#2e3105] hover:bg-[#404615]"
              }`}
            >
              {isSubmitting ? "SUBMITTING..." : "SUBMIT"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
