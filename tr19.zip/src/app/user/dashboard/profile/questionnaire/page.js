import Questionnaire from "@/components/user/profile/questionnaire";

export default function Page() {
    return <Questionnaire />;
}