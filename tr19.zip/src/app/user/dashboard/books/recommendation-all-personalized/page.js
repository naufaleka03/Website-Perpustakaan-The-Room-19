import RecommendationAllPersonalized from "@/components/user/books/recommendation-all-personalized";

export default function Page() {
  return <RecommendationAllPersonalized />;
}