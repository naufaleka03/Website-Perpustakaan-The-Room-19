import History from "@/components/user/books/history";

export default function Page() {
  return <History />;
}
