import RecommendationAllInteraction from "@/components/user/books/recommendation-all-interaction";

export default function Page() {
  return <RecommendationAllInteraction />;
}