import Catalog from "@/components/user/books/catalog";

export default function Page() {
  return <Catalog />;
}
