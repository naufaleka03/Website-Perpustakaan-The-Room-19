import UserDashboard from '@/components/user/dashboard/dashboard';

export default function Page() {
  return <UserDashboard />;
}