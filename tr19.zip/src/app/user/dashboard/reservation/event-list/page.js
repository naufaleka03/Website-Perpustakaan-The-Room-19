import ListEvent from '@/components/user/reservation/ListEvent';

export default function Page() {
  return <ListEvent />;
} 