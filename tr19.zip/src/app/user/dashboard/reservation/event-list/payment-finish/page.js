"use client";

import PaymentFinishEvent from "@/components/payment/payment-finish-event";

export default function Page() {
  return <PaymentFinishEvent />;
}
