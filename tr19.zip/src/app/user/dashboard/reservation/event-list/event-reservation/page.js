"use client"
import EventReservation from '@/components/user/reservation/EventReservation';

export default function EventReservationPage() {
  return <EventReservation />;
}
