"use client"
import Histories from '@/components/user/reservation/Histories';

export default function ReservationHistoryCard() {
  return <Histories />;
}
