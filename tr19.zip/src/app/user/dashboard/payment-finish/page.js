'use client';

import PaymentFinish from '@/components/payment/payment-finish';

export default function Page() {
  return <PaymentFinish />;
}

