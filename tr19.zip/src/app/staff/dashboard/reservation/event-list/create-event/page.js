import CreateEvent from '@/components/staff/reservation/event-list/CreateEvent';

export default function Page() {
  return <CreateEvent />;
} 