import EventListStaff from '@/components/staff/reservation/event-list/EventListStaff';

export default function Page() {
  return <EventListStaff />;
} 