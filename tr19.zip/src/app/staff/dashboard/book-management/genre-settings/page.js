import GenreSettings from "@/components/staff/book-management/genre-settings";

export default function Page() {
  return <GenreSettings />;
}
