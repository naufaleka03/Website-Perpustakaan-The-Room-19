import EditBook from "@/components/staff/book-management/edit-book";

export default function StaffEditBook() {
  return <EditBook />;
} 