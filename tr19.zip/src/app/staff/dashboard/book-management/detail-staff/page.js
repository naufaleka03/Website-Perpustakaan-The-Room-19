import DetailStaff from "@/components/staff/book-management/detail-staff";

export default function Page() {
  return <DetailStaff />;
}
