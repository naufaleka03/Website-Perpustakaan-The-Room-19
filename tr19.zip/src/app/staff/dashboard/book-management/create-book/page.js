import CreateBook from "@/components/staff/book-management/create-book";

export default function Page() {
  return <CreateBook />;
}
