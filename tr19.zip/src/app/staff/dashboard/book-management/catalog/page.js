import CatalogStaff from "@/components/staff/book-management/catalog-staff";

export default function Page() {
  return <CatalogStaff />;
}
