import DataCollection from '@/components/staff/data-collection/DataCollection';

export default function Page() {
  return <DataCollection />;
}