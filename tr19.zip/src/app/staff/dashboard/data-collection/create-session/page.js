import CreateSession from '@/components/staff/data-collection/CreateSession';

export default function Page() {
  return <CreateSession />;
}