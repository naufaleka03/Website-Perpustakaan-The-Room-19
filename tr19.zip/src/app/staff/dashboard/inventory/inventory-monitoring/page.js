import InventoryMonitoring from '@/components/staff/inventory/inventory-monitoring';

export default function Page() {
  return <InventoryMonitoring />;
} 