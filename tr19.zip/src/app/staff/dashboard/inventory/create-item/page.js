import CreateItem from "@/components/staff/inventory/create-item";

export default function CreateItemPage() {
  return <CreateItem />;
}
