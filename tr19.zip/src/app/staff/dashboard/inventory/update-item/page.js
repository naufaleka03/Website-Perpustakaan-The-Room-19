import UpdateItem from "@/components/staff/inventory/update-item";

export default function UpdateItemPage() {
  return <UpdateItem />;
}
