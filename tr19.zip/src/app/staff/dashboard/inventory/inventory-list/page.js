import InventoryList from '@/components/staff/inventory/inventory-list';

export default function Page() {
  return <InventoryList />;
} 