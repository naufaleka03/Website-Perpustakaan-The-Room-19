/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['bsrqchgbsrbuwzuspbkw.supabase.co'],
  },
};

export default nextConfig;
